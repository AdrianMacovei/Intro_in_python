#Step 5
from replit import clear
import random
import hangman_words#command for importing words from this module

chosen_word = random.choice(hangman_words.word_list)
word_length = len(chosen_word)

end_of_game = False
lives = 6

import hangman_art
print(hangman_art.logo)

#For Testing code
print(f'Pssst, the solution is {chosen_word}.')

#Create blanks
display = [] #create list display
for _ in range(word_length):
    display += "_"
#create "_" on display how much word lenght are
while not end_of_game:#looping for conditions
    guess = input("Guess a letter: ").lower()
    
    clear()#this function delete previous answerson the loop
    
    if guess in display:
        print(f"You already chose that letter {guess}! Please chose another")
    #TODO-4: - If the user has entered a letter they've already guessed, print the letter and let them know.

    #Check guessed letter
    for position in range(word_length):
        letter = chosen_word[position]
        #print(f"Current position: {position}\n Current letter: {letter}\n Guessed letter: {guess}")
        if letter == guess:
            display[position] = letter

    #Check if user is wrong.
    if guess not in chosen_word:
        #TODO-5: - If the letter is not in the chosen_word, print out the letter and let them know it's not in the word.
        lives -= 1
        print(f"Letter {guess} is'n in the word. You lose a life! Try to guess again!")
        if lives == 0:
            end_of_game = True
            print("You lose.")

    #Join all the elements in the list and turn it into a String.
    print(f"{' '.join(display)}")

    #Check if user has got all letters.
    if "_" not in display:
        end_of_game = True
        print("You win.")

    #TODO-2: - Import the stages from hangman_art.py and make this error go away.
    print(hangman_art.stages[lives]) #coommand to print diferent ASCII for how much lives remaining